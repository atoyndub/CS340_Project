//execution code
loadList("HomePersonsList", "person_profile.html");
loadList("HomePlacesList", "place_profile.html");
loadList("HomeEventsList", "event_profile.html");