//execution code
loadList("EventProfilePersonsList", "person_profile.html");