//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("UpdatePlace_PersonToggle", "UpdatePlace_PersonSelector", "UpdatePlace_PersonSelectorList", "UpdatePlace_PersonLinkList");
addRemoveOptionToSelectionListElements("UpdatePlace_PersonLinkList");
loadSelectorList("UpdatePlace_EventToggle", "UpdatePlace_EventSelector", "UpdatePlace_EventSelectorList", "UpdatePlace_EventLinkList");
addRemoveOptionToSelectionListElements("UpdatePlace_EventLinkList");
loadSelectorList("UpdatePlace_PhotoToggle", "UpdatePlace_PhotoSelector", "UpdatePlace_PhotoSelectorList", "UpdatePlace_PhotoLinkList");
addRemoveOptionToSelectionListElements("UpdatePlace_PhotoLinkList");
