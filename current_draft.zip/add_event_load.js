//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("AddEvent_PersonToggle", "AddEvent_PersonSelector", "AddEvent_PersonSelectorList", "AddEvent_PersonLinkList");
loadSelectorList("AddEvent_PlaceToggle", "AddEvent_PlaceSelector", "AddEvent_PlaceSelectorList", "AddEvent_PlaceLinkList");
loadSelectorList("AddEvent_PhotoToggle", "AddEvent_PhotoSelector", "AddEvent_PhotoSelectorList", "AddEvent_PhotoLinkList");
