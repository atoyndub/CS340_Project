//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("AddPlace_PersonToggle", "AddPlace_PersonSelector", "AddPlace_PersonSelectorList", "AddPlace_PersonLinkList");
loadSelectorList("AddPlace_EventToggle", "AddPlace_EventSelector", "AddPlace_EventSelectorList", "AddPlace_EventLinkList");
loadSelectorList("AddPlace_PhotoToggle", "AddPlace_PhotoSelector", "AddPlace_PhotoSelectorList", "AddPlace_PhotoLinkList");
