//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("UpdateEvent_PersonToggle", "UpdateEvent_PersonSelector", "UpdateEvent_PersonSelectorList", "UpdateEvent_PersonLinkList");
addRemoveOptionToSelectionListElements("UpdateEvent_PersonLinkList");
loadSelectorList("UpdateEvent_PlaceToggle", "UpdateEvent_PlaceSelector", "UpdateEvent_PlaceSelectorList", "UpdateEvent_PlaceLinkList");
addRemoveOptionToSelectionListElements("UpdateEvent_PlaceLinkList");
loadSelectorList("UpdateEvent_PhotoToggle", "UpdateEvent_PhotoSelector", "UpdateEvent_PhotoSelectorList", "UpdateEvent_PhotoLinkList");
addRemoveOptionToSelectionListElements("UpdateEvent_PhotoLinkList");
