//execution code
loadList("HomePersonsList", goToPersonProfile);
loadList("HomePlacesList", goToPlaceProfile);
loadList("HomeEventsList", goToEventProfile);
