//execution code
loadList("EventProfilePersonsList", goToPersonProfile);
loadList("EventProfilePlacesList", goToPlaceProfile);
loadGallery("EventProfileImagesList");
