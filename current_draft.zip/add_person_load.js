//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("AddPerson_ParentToggle", "AddPerson_ParentSelector", "AddPerson_ParentSelectorList", "AddPerson_ParentLinkList");
loadSelectorList("AddPerson_SpouseToggle", "AddPerson_SpouseSelector", "AddPerson_SpouseSelectorList", "AddPerson_SpouseLinkList");
loadSelectorList("AddPerson_ChildToggle", "AddPerson_ChildSelector", "AddPerson_ChildSelectorList", "AddPerson_ChildLinkList");
loadSelectorList("AddPerson_PlaceToggle", "AddPerson_PlaceSelector", "AddPerson_PlaceSelectorList", "AddPerson_PlaceLinkList");
loadSelectorList("AddPerson_EventToggle", "AddPerson_EventSelector", "AddPerson_EventSelectorList", "AddPerson_EventLinkList");
loadSelectorList("AddPerson_PhotoToggle", "AddPerson_PhotoSelector", "AddPerson_PhotoSelectorList", "AddPerson_PhotoLinkList");
