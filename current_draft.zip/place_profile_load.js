//execution code
loadList("PlaceProfilePersonsList", goToPersonProfile);
loadList("PlaceProfileEventsList", goToEventProfile);
loadGallery("PlaceProfileImagesList");
