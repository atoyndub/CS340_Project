//execution code
loadList("PersonProfileParentsList", goToPersonProfile);
loadList("PersonProfileSpousesList", goToPersonProfile);
loadList("PersonProfileChildrenList", goToPersonProfile);
loadList("PersonProfilePlacesList", goToPlaceProfile);
loadList("PersonProfileEventsList", goToEventProfile);
loadGallery("PersonProfileGalleryImagesList");
