//execution code
loadList("PhotoProfilePersonsList", goToPersonProfile);
loadList("PhotoProfilePlacesList", goToPlaceProfile);
loadList("PhotoProfileEventsList", goToEventProfile);
