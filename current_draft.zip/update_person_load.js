//loadSelectorList(toggleID, selectorListID, selectorListBodyID, destinationListBodyID)
loadSelectorList("UpdatePerson_ParentToggle", "UpdatePerson_ParentSelector", "UpdatePerson_ParentSelectorList", "UpdatePerson_ParentLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_ParentLinkList");
loadSelectorList("UpdatePerson_SpouseToggle", "UpdatePerson_SpouseSelector", "UpdatePerson_SpouseSelectorList", "UpdatePerson_SpouseLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_SpouseLinkList");
loadSelectorList("UpdatePerson_ChildToggle", "UpdatePerson_ChildSelector", "UpdatePerson_ChildSelectorList", "UpdatePerson_ChildLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_ChildLinkList");
loadSelectorList("UpdatePerson_PlaceToggle", "UpdatePerson_PlaceSelector", "UpdatePerson_PlaceSelectorList", "UpdatePerson_PlaceLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_PlaceLinkList");
loadSelectorList("UpdatePerson_EventToggle", "UpdatePerson_EventSelector", "UpdatePerson_EventSelectorList", "UpdatePerson_EventLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_EventLinkList");
loadSelectorList("UpdatePerson_PhotoToggle", "UpdatePerson_PhotoSelector", "UpdatePerson_PhotoSelectorList", "UpdatePerson_PhotoLinkList");
addRemoveOptionToSelectionListElements("UpdatePerson_PhotoLinkList");
